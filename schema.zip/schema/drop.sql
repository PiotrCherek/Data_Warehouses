DROP TABLE Posters;
DROP TABLE Rents;
DROP TABLE TournamentParticipants;
DROP TABLE Tournaments;
DROP TABLE Workers;
DROP TABLE OwnedBoardGames;
DROP TABLE CustomerAccountInfo;